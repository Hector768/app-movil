import { ReactNode } from "react";
import BottomNavigation from "./BottomNavigation";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="max-w-md mx-auto bg-dark-bg min-h-screen relative pb-20">
      {/* Header */}
      <header className="bg-gradient-to-r from-gold to-yellow-500 p-4 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-dark-bg rounded-lg flex items-center justify-center">
              <span className="text-gold font-bold text-sm">CA</span>
            </div>
          </div>
          
          <h1 className="text-dark-bg font-bold text-lg">Inversiones Cruz Angeles</h1>
          
          <div className="flex space-x-1 text-dark-bg text-sm">
            <span>📶</span>
            <span>📶</span>
            <span>🔋</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6">
        {children}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}
