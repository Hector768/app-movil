import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { CartItemWithProduct } from "@shared/schema";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  const { data: cartItems } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart"],
  });

  const cartItemsCount = cartItems?.length || 0;

  const navItems = [
    { path: "/", label: "Inicio", icon: "🏠" },
    { path: "/products", label: "Productos", icon: "📦" },
    { path: "/cart", label: "Carrito", icon: "🛒", badge: cartItemsCount },
    { path: "/contact", label: "Contacto", icon: "📞" },
    { path: "/profile", label: "Perfil", icon: "👤" },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-card-bg border-t border-gray-600">
      <div className="flex justify-around py-2">
        {navItems.map((item) => (
          <Button
            key={item.path}
            variant="ghost"
            onClick={() => setLocation(item.path)}
            className={`flex flex-col items-center py-2 px-3 h-auto relative ${
              location === item.path 
                ? "text-gold" 
                : "text-gray-400 hover:text-gold"
            }`}
          >
            <span className="text-lg mb-1">{item.icon}</span>
            <span className="text-xs">{item.label}</span>
            {item.badge && item.badge > 0 && (
              <span className="absolute -top-1 -right-1 bg-gold text-dark-bg text-xs w-5 h-5 rounded-full flex items-center justify-center font-medium">
                {item.badge}
              </span>
            )}
          </Button>
        ))}
      </div>
    </nav>
  );
}
