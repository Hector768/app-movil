import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  showAddButton?: boolean;
}

export default function ProductCard({ product, showAddButton = true }: ProductCardProps) {
  const { toast } = useToast();

  const addToCartMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/cart", {
      productId: product.id,
      quantity: 1,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Producto agregado",
        description: `${product.name} se agregó al carrito`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (showAddButton && !product) {
    return (
      <Button 
        onClick={() => addToCartMutation.mutate()}
        disabled={addToCartMutation.isPending}
        className="bg-gold text-dark-bg px-3 py-2 rounded-lg text-sm font-medium hover:bg-gold/90"
      >
        +
      </Button>
    );
  }

  return (
    <Card className="bg-card-bg border-none overflow-hidden hover:scale-105 transition-transform">
      <img 
        src={product.imageUrl || "/placeholder-product.jpg"} 
        alt={product.name}
        className="w-full h-32 object-cover"
      />
      <CardContent className="p-3">
        <h3 className="font-medium text-sm mb-1">{product.name}</h3>
        <p className="text-gray-400 text-xs mb-2">{product.dimensions}</p>
        <p className="text-gold font-bold text-sm mb-3">S/ {product.price}</p>
        {showAddButton && (
          <Button 
            onClick={() => addToCartMutation.mutate()}
            disabled={addToCartMutation.isPending || !product.inStock}
            className="w-full bg-gold text-dark-bg hover:bg-gold/90 text-xs font-medium disabled:bg-gray-600"
          >
            {!product.inStock ? "Sin Stock" : "Agregar al Carrito"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
