import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { CartItemWithProduct } from "@shared/schema";

interface CartItemProps {
  item: CartItemWithProduct;
}

export default function CartItem({ item }: CartItemProps) {
  const { toast } = useToast();

  const updateQuantityMutation = useMutation({
    mutationFn: (quantity: number) => apiRequest("PATCH", `/api/cart/${item.id}`, { quantity }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/cart/${item.id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Producto eliminado",
        description: `${item.product.name} se eliminó del carrito`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleIncreaseQuantity = () => {
    updateQuantityMutation.mutate(item.quantity + 1);
  };

  const handleDecreaseQuantity = () => {
    if (item.quantity > 1) {
      updateQuantityMutation.mutate(item.quantity - 1);
    }
  };

  const handleRemoveItem = () => {
    removeItemMutation.mutate();
  };

  return (
    <Card className="bg-card-bg border-none">
      <CardContent className="p-4 flex items-center space-x-4">
        <img 
          src={item.product.imageUrl || "/placeholder-product.jpg"} 
          alt={item.product.name}
          className="w-16 h-16 rounded-lg object-cover"
        />
        <div className="flex-1">
          <h3 className="font-medium text-sm">{item.product.name}</h3>
          <p className="text-gray-400 text-xs">{item.product.dimensions}</p>
          <p className="text-gold font-bold text-sm">S/ {item.product.price}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDecreaseQuantity}
            disabled={item.quantity <= 1 || updateQuantityMutation.isPending}
            className="w-8 h-8 bg-gold text-dark-bg rounded-full border-none hover:bg-gold/90 p-0"
          >
            -
          </Button>
          <span className="w-8 text-center text-sm">{item.quantity}</span>
          <Button
            variant="outline"
            size="sm"
            onClick={handleIncreaseQuantity}
            disabled={updateQuantityMutation.isPending}
            className="w-8 h-8 bg-gold text-dark-bg rounded-full border-none hover:bg-gold/90 p-0"
          >
            +
          </Button>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRemoveItem}
          disabled={removeItemMutation.isPending}
          className="text-red-400 hover:text-red-300 hover:bg-red-400/10 p-2"
        >
          🗑️
        </Button>
      </CardContent>
    </Card>
  );
}
