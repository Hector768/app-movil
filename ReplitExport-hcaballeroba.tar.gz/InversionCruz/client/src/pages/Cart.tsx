import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import CartItem from "@/components/CartItem";
import type { CartItemWithProduct } from "@shared/schema";

const orderSchema = z.object({
  deliveryAddress: z.string().min(10, "La dirección debe tener al menos 10 caracteres"),
  additionalNotes: z.string().optional(),
});

type OrderForm = z.infer<typeof orderSchema>;

export default function Cart() {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const { toast } = useToast();

  const { data: cartItems, isLoading } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart"],
  });

  const clearCartMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", "/api/cart"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Carrito limpiado",
        description: "Se han eliminado todos los productos del carrito",
      });
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: (data: OrderForm) => apiRequest("POST", "/api/orders", data),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setIsCheckoutOpen(false);
      
      // Open WhatsApp with the order details
      const phoneNumber = "51999888777"; // Replace with actual business phone
      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(response.whatsappMessage)}`;
      window.open(whatsappUrl, '_blank');
      
      toast({
        title: "Pedido creado exitosamente",
        description: "Se abrirá WhatsApp para confirmar tu pedido",
      });
    },
    onError: (error) => {
      toast({
        title: "Error al crear el pedido",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<OrderForm>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      deliveryAddress: "",
      additionalNotes: "",
    },
  });

  const onSubmit = (data: OrderForm) => {
    createOrderMutation.mutate(data);
  };

  const cartItemsArray = cartItems || [];
  const subtotal = cartItemsArray.reduce((sum, item) => 
    sum + (parseFloat(item.product.price) * item.quantity), 0
  );
  const total = subtotal; // Free delivery

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="h-6 w-24 bg-card-bg rounded animate-pulse"></div>
          <div className="h-4 w-16 bg-card-bg rounded animate-pulse"></div>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-card-bg rounded-xl h-24 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  if (cartItemsArray.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-card-bg rounded-full mx-auto mb-4 flex items-center justify-center">
          <span className="text-2xl">🛒</span>
        </div>
        <h3 className="text-lg font-medium mb-2">Tu carrito está vacío</h3>
        <p className="text-gray-400 text-sm mb-6">
          Agrega algunos productos para comenzar tu pedido
        </p>
        <Button 
          onClick={() => window.history.back()}
          className="bg-gold text-dark-bg hover:bg-gold/90"
        >
          Explorar Productos
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Mi Carrito</h2>
        <span className="text-gray-400 text-sm">
          {cartItemsArray.length} producto{cartItemsArray.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Cart Items */}
      <div className="space-y-3">
        {cartItemsArray.map((item) => (
          <CartItem key={item.id} item={item} />
        ))}
      </div>

      {/* Cart Summary */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-4 space-y-3">
          <div className="flex justify-between text-sm">
            <span>Subtotal:</span>
            <span>S/ {subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Entrega:</span>
            <span className="text-green-400">Gratis</span>
          </div>
          <div className="border-t border-gray-600 pt-3">
            <div className="flex justify-between font-bold">
              <span>Total:</span>
              <span className="text-gold">S/ {total.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex space-x-3">
        <Button
          variant="outline"
          onClick={() => clearCartMutation.mutate()}
          disabled={clearCartMutation.isPending}
          className="flex-1 border-gray-600 text-gray-300 hover:bg-card-bg"
        >
          Limpiar Carrito
        </Button>
        
        <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
          <DialogTrigger asChild>
            <Button className="flex-1 bg-gold text-dark-bg hover:bg-gold/90 font-bold">
              Realizar Pedido
            </Button>
          </DialogTrigger>
          
          <DialogContent className="bg-card-bg border-gray-600 text-white">
            <DialogHeader>
              <DialogTitle>Confirmar Pedido</DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="deliveryAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dirección de Entrega</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Ingresa tu dirección completa..."
                          className="bg-dark-bg border-gray-600 text-white resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Comentario Adicional (Opcional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Instrucciones especiales..."
                          className="bg-dark-bg border-gray-600 text-white resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Card className="bg-dark-bg border-gray-600">
                  <CardContent className="p-4">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total a Pagar:</span>
                      <span className="text-gold">S/ {total.toFixed(2)}</span>
                    </div>
                  </CardContent>
                </Card>

                <Button 
                  type="submit"
                  disabled={createOrderMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700 font-bold py-3 flex items-center justify-center space-x-3"
                >
                  <span>💬</span>
                  <span>Enviar por WhatsApp</span>
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
