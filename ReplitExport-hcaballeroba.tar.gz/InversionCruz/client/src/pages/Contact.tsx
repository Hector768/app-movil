import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";

const contactSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  phone: z.string().min(9, "Ingresa un número de teléfono válido"),
  message: z.string().min(10, "El mensaje debe tener al menos 10 caracteres"),
});

type ContactForm = z.infer<typeof contactSchema>;

export default function Contact() {
  const { user } = useAuth();
  const { toast } = useToast();

  const contactMutation = useMutation({
    mutationFn: (data: ContactForm) => apiRequest("POST", "/api/contacts", data),
    onSuccess: (response) => {
      toast({
        title: "Mensaje enviado",
        description: "Nos contactaremos contigo pronto",
      });
      
      // Open WhatsApp with the contact message
      const phoneNumber = "51999888777"; // Replace with actual business phone
      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(response.whatsappMessage)}`;
      window.open(whatsappUrl, '_blank');
      
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error al enviar mensaje",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : "",
      phone: user?.phone || "",
      message: "",
    },
  });

  const onSubmit = (data: ContactForm) => {
    contactMutation.mutate(data);
  };

  const handleCall = () => {
    window.location.href = "tel:+51999888777";
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Contáctanos</h2>

      {/* Contact Form */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nombre</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-dark-bg border-gray-600 text-white"
                        placeholder="Tu nombre completo"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Teléfono</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="tel"
                        className="bg-dark-bg border-gray-600 text-white"
                        placeholder="+51 999 888 777"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mensaje</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        rows={4}
                        className="bg-dark-bg border-gray-600 text-white resize-none"
                        placeholder="Escribe tu mensaje aquí..."
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex space-x-3">
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700 flex items-center justify-center space-x-2"
                >
                  <span>💬</span>
                  <span>WhatsApp</span>
                </Button>
                
                <Button
                  type="button"
                  onClick={handleCall}
                  variant="outline"
                  className="flex-1 bg-gold text-dark-bg border-gold hover:bg-gold/90 flex items-center justify-center space-x-2"
                >
                  <span>📞</span>
                  <span>Llamar</span>
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Quick Contact Info */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold">Información de Contacto</h3>
        
        <div className="space-y-3">
          <Card className="bg-card-bg border-none">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg">📍</span>
              </div>
              <div>
                <p className="font-medium">Dirección</p>
                <p className="text-gray-400 text-sm">Av. Principales 123, Lima, Perú</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card-bg border-none">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg">🕒</span>
              </div>
              <div>
                <p className="font-medium">Horarios</p>
                <p className="text-gray-400 text-sm">Lun - Sáb: 8:00 AM - 6:00 PM</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card-bg border-none">
            <CardContent className="p-4 flex items-center space-x-3">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg">📞</span>
              </div>
              <div>
                <p className="font-medium">Teléfono</p>
                <p className="text-gray-400 text-sm">+51 999 888 777</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
