import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import ProductCard from "@/components/ProductCard";
import type { Product, CartItemWithProduct } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: cartItems } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart"],
  });

  const featuredProducts = products?.slice(0, 3) || [];
  const cartItemsCount = cartItems?.length || 0;

  const getFirstName = () => {
    if (user?.firstName) return user.firstName;
    return "Usuario";
  };

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6 text-center">
          <div className="w-16 h-16 bg-gold rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <span className="text-dark-bg font-bold text-2xl">CA</span>
          </div>
          <h1 className="text-xl font-bold mb-2">Inversiones Cruz Angeles</h1>
          <p className="text-gray-400 text-sm mb-4">
            Bienvenido, <span className="text-gold">{getFirstName()}</span>
          </p>
          <img 
            src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
            alt="Muestras de melamina en diferentes colores y texturas" 
            className="rounded-xl w-full h-32 object-cover mb-4"
          />
          <p className="text-gold text-sm font-medium">
            "Transformamos tus espacios con elegancia y durabilidad."
          </p>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button 
          variant="outline"
          className="bg-card-bg border-none p-4 h-auto flex flex-col items-center space-y-2 hover:bg-card-bg/80"
          onClick={() => setLocation("/products")}
        >
          <div className="w-8 h-8 text-gold text-2xl">📦</div>
          <span className="text-sm font-medium">Ver Productos</span>
        </Button>
        
        <Button 
          variant="outline"
          className="bg-card-bg border-none p-4 h-auto flex flex-col items-center space-y-2 hover:bg-card-bg/80 relative"
          onClick={() => setLocation("/cart")}
        >
          <div className="w-8 h-8 text-gold text-2xl">🛒</div>
          <span className="text-sm font-medium">Mi Carrito</span>
          {cartItemsCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-gold text-dark-bg text-xs px-2 py-1 rounded-full">
              {cartItemsCount}
            </span>
          )}
        </Button>
      </div>

      {/* Featured Products */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold">Productos Destacados</h2>
        <div className="space-y-3">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="bg-card-bg border-none">
              <CardContent className="p-4 flex items-center space-x-4">
                <img 
                  src={product.imageUrl || "/placeholder-product.jpg"} 
                  alt={product.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-medium">{product.name}</h3>
                  <p className="text-gray-400 text-sm">{product.dimensions}</p>
                  <p className="text-gold font-bold">S/ {product.price}</p>
                </div>
                <ProductCard product={product} showAddButton />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
