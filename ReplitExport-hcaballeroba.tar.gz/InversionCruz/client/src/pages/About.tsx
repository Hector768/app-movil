import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  const openGoogleMaps = () => {
    // In a real implementation, use actual coordinates
    const mapsUrl = "https://maps.google.com/?q=Av.+Principales+123,+Lima,+Peru";
    window.open(mapsUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Sobre Nosotros</h2>

      {/* Company Story */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6">
          <h3 className="text-lg font-bold mb-4 text-gold">Nuestra Historia</h3>
          <img 
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300" 
            alt="Showroom moderno con muestras de melamina" 
            className="w-full h-40 object-cover rounded-lg mb-4"
          />
          <p className="text-gray-300 text-sm leading-relaxed">
            Con más de 15 años de experiencia en el mercado, Inversiones Cruz Angeles se ha consolidado 
            como líder en la distribución de melamina de alta calidad. Nos especializamos en ofrecer 
            soluciones innovadoras para el diseño de interiores y la construcción de muebles.
          </p>
        </CardContent>
      </Card>

      {/* Mission & Vision */}
      <div className="grid grid-cols-1 gap-4">
        <Card className="bg-card-bg border-none">
          <CardContent className="p-4">
            <h4 className="font-bold text-gold mb-2">Misión</h4>
            <p className="text-gray-300 text-sm">
              Proporcionar materiales de melamina de la más alta calidad, transformando espacios 
              con elegancia y durabilidad.
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-card-bg border-none">
          <CardContent className="p-4">
            <h4 className="font-bold text-gold mb-2">Visión</h4>
            <p className="text-gray-300 text-sm">
              Ser la empresa líder en Perú en la distribución de melamina, reconocida por nuestra 
              excelencia y servicio al cliente.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Values */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6">
          <h3 className="text-lg font-bold mb-4 text-gold">Nuestros Valores</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-gold rounded-xl mx-auto mb-2 flex items-center justify-center">
                <span className="text-dark-bg text-xl">🏆</span>
              </div>
              <h4 className="font-medium text-sm">Calidad</h4>
              <p className="text-gray-400 text-xs">Productos premium</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gold rounded-xl mx-auto mb-2 flex items-center justify-center">
                <span className="text-dark-bg text-xl">🤝</span>
              </div>
              <h4 className="font-medium text-sm">Confianza</h4>
              <p className="text-gray-400 text-xs">15+ años de experiencia</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gold rounded-xl mx-auto mb-2 flex items-center justify-center">
                <span className="text-dark-bg text-xl">🚀</span>
              </div>
              <h4 className="font-medium text-sm">Innovación</h4>
              <p className="text-gray-400 text-xs">Soluciones modernas</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gold rounded-xl mx-auto mb-2 flex items-center justify-center">
                <span className="text-dark-bg text-xl">⭐</span>
              </div>
              <h4 className="font-medium text-sm">Servicio</h4>
              <p className="text-gray-400 text-xs">Atención personalizada</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Location & Contact Info */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6">
          <h3 className="text-lg font-bold mb-4 text-gold">Visítanos</h3>
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=200" 
            alt="Fachada moderna de tienda de materiales" 
            className="w-full h-32 object-cover rounded-lg mb-4"
          />
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg text-sm">📍</span>
              </div>
              <span className="text-sm">Av. Principales 123, Lima, Perú</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg text-sm">🕒</span>
              </div>
              <span className="text-sm">Lun - Sáb: 8:00 AM - 6:00 PM</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-dark-bg text-sm">📞</span>
              </div>
              <span className="text-sm">+51 999 888 777</span>
            </div>
          </div>
          
          <Button 
            onClick={openGoogleMaps}
            className="w-full bg-gold text-dark-bg hover:bg-gold/90 font-medium mt-4 flex items-center justify-center space-x-2"
          >
            <span>🗺️</span>
            <span>Ver en Google Maps</span>
          </Button>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card-bg border-none">
          <CardContent className="p-4 text-center">
            <h4 className="text-2xl font-bold text-gold">15+</h4>
            <p className="text-gray-400 text-xs">Años de experiencia</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card-bg border-none">
          <CardContent className="p-4 text-center">
            <h4 className="text-2xl font-bold text-gold">1000+</h4>
            <p className="text-gray-400 text-xs">Clientes satisfechos</p>
          </CardContent>
        </Card>
        
        <Card className="bg-card-bg border-none">
          <CardContent className="p-4 text-center">
            <h4 className="text-2xl font-bold text-gold">50+</h4>
            <p className="text-gray-400 text-xs">Variedades de melamina</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
