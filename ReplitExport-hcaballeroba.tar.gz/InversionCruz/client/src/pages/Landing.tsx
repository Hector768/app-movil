import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo and Company Name */}
        <div className="text-center">
          <div className="w-24 h-24 bg-gold rounded-3xl mx-auto mb-6 flex items-center justify-center">
            <span className="text-dark-bg font-bold text-3xl">CA</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">Inversiones Cruz Angeles</h1>
          <p className="text-gray-400 text-lg">"Transformamos tus espacios con elegancia y durabilidad"</p>
        </div>

        {/* Welcome Card */}
        <Card className="bg-card-bg border-none">
          <CardContent className="p-6 text-center">
            <img 
              src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Muestras de melamina en diferentes colores y texturas" 
              className="rounded-xl w-full h-48 object-cover mb-6"
            />
            <h2 className="text-xl font-bold mb-4">Bienvenido a nuestra tienda</h2>
            <p className="text-gray-300 mb-6">
              Descubre nuestra amplia selección de melamina de alta calidad. 
              Más de 15 años de experiencia nos respaldan.
            </p>
            
            <div className="space-y-4">
              <Button 
                onClick={handleLogin}
                className="w-full bg-gold text-dark-bg hover:bg-gold/90 font-bold py-3"
                size="lg"
              >
                Iniciar Sesión / Registrarse
              </Button>
              
              <div className="flex items-center space-x-4 text-sm text-gray-400">
                <div className="flex-1 h-px bg-gray-600"></div>
                <span>Acceso rápido y seguro</span>
                <div className="flex-1 h-px bg-gray-600"></div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card-bg rounded-xl p-4 text-center">
            <div className="w-8 h-8 bg-gold rounded-lg mx-auto mb-2 flex items-center justify-center">
              <span className="text-dark-bg text-sm">📦</span>
            </div>
            <p className="text-sm font-medium">Productos de Calidad</p>
          </div>
          
          <div className="bg-card-bg rounded-xl p-4 text-center">
            <div className="w-8 h-8 bg-gold rounded-lg mx-auto mb-2 flex items-center justify-center">
              <span className="text-dark-bg text-sm">🚀</span>
            </div>
            <p className="text-sm font-medium">Entrega Rápida</p>
          </div>
          
          <div className="bg-card-bg rounded-xl p-4 text-center">
            <div className="w-8 h-8 bg-gold rounded-lg mx-auto mb-2 flex items-center justify-center">
              <span className="text-dark-bg text-sm">💬</span>
            </div>
            <p className="text-sm font-medium">Pedidos por WhatsApp</p>
          </div>
          
          <div className="bg-card-bg rounded-xl p-4 text-center">
            <div className="w-8 h-8 bg-gold rounded-lg mx-auto mb-2 flex items-center justify-center">
              <span className="text-dark-bg text-sm">⭐</span>
            </div>
            <p className="text-sm font-medium">15+ Años de Experiencia</p>
          </div>
        </div>
      </div>
    </div>
  );
}
