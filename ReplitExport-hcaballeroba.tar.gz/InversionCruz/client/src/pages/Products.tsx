import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ProductCard from "@/components/ProductCard";
import type { Product } from "@shared/schema";

export default function Products() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<string>("all");

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filters = [
    { key: "all", label: "Todos" },
    { key: "color", label: "Color" },
    { key: "thickness", label: "Espesor" },
    { key: "brand", label: "Marca" },
  ];

  const filteredProducts = products?.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-4">
          <div className="h-12 bg-card-bg rounded-xl animate-pulse"></div>
          <div className="flex space-x-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-8 w-16 bg-card-bg rounded-full animate-pulse"></div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-card-bg rounded-xl h-64 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filter Bar */}
      <div className="space-y-4">
        <div className="relative">
          <Input
            type="text"
            placeholder="Buscar productos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-card-bg border-none text-white placeholder:text-gray-400 pl-12"
          />
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
            🔍
          </div>
        </div>

        {/* Filter Chips */}
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {filters.map((filter) => (
            <Badge
              key={filter.key}
              variant={activeFilter === filter.key ? "default" : "secondary"}
              className={`cursor-pointer whitespace-nowrap ${
                activeFilter === filter.key 
                  ? "bg-gold text-dark-bg" 
                  : "bg-card-bg text-white hover:bg-card-bg/80"
              }`}
              onClick={() => setActiveFilter(filter.key)}
            >
              {filter.label}
            </Badge>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-2 gap-4">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* Empty State */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-card-bg rounded-full mx-auto mb-4 flex items-center justify-center">
            <span className="text-2xl">📦</span>
          </div>
          <h3 className="text-lg font-medium mb-2">No se encontraron productos</h3>
          <p className="text-gray-400 text-sm">
            {searchQuery 
              ? "Intenta con otros términos de búsqueda" 
              : "No hay productos disponibles en este momento"
            }
          </p>
        </div>
      )}
    </div>
  );
}
