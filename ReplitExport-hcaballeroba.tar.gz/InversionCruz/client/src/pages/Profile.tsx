import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { OrderWithItems } from "@shared/schema";

const profileSchema = z.object({
  firstName: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  lastName: z.string().min(2, "El apellido debe tener al menos 2 caracteres"),
  phone: z.string().min(9, "Ingresa un número de teléfono válido"),
  address: z.string().optional(),
});

type ProfileForm = z.infer<typeof profileSchema>;

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [showOrders, setShowOrders] = useState(false);

  const { data: orders } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders"],
    enabled: showOrders,
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data: ProfileForm) => apiRequest("PATCH", "/api/profile", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsEditOpen(false);
      toast({
        title: "Perfil actualizado",
        description: "Tu información ha sido actualizada exitosamente",
      });
    },
    onError: (error) => {
      toast({
        title: "Error al actualizar perfil",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      phone: user?.phone || "",
      address: user?.address || "",
    },
  });

  const onSubmit = (data: ProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { label: "Pendiente", color: "bg-yellow-600" },
      confirmed: { label: "Confirmado", color: "bg-blue-600" },
      delivered: { label: "Entregado", color: "bg-green-600" },
      cancelled: { label: "Cancelado", color: "bg-red-600" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${config.color}`}>
        {config.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Mi Perfil</h2>

      {/* User Info Card */}
      <Card className="bg-card-bg border-none">
        <CardContent className="p-6 text-center">
          <div className="w-20 h-20 bg-gold rounded-full mx-auto mb-4 flex items-center justify-center">
            {user?.profileImageUrl ? (
              <img 
                src={user.profileImageUrl} 
                alt="Profile" 
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <span className="text-dark-bg text-2xl">👤</span>
            )}
          </div>
          <h3 className="text-lg font-bold">
            {user?.firstName && user?.lastName 
              ? `${user.firstName} ${user.lastName}` 
              : "Usuario"
            }
          </h3>
          <p className="text-gray-400 text-sm">{user?.email}</p>
          {user?.phone && (
            <p className="text-gray-400 text-sm">{user.phone}</p>
          )}
        </CardContent>
      </Card>

      {/* Profile Options */}
      <div className="space-y-3">
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline"
              className="w-full bg-card-bg border-none p-4 h-auto flex items-center justify-between hover:bg-card-bg/80"
            >
              <div className="flex items-center space-x-3">
                <span className="text-gold">✏️</span>
                <span>Editar Perfil</span>
              </div>
              <span className="text-gray-400">→</span>
            </Button>
          </DialogTrigger>
          
          <DialogContent className="bg-card-bg border-gray-600 text-white">
            <DialogHeader>
              <DialogTitle>Editar Perfil</DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          className="bg-dark-bg border-gray-600 text-white"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Apellido</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          className="bg-dark-bg border-gray-600 text-white"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Teléfono</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="tel"
                          className="bg-dark-bg border-gray-600 text-white"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dirección</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          className="bg-dark-bg border-gray-600 text-white resize-none"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit"
                  disabled={updateProfileMutation.isPending}
                  className="w-full bg-gold text-dark-bg hover:bg-gold/90"
                >
                  Guardar Cambios
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        <Button 
          variant="outline"
          onClick={() => setShowOrders(!showOrders)}
          className="w-full bg-card-bg border-none p-4 h-auto flex items-center justify-between hover:bg-card-bg/80"
        >
          <div className="flex items-center space-x-3">
            <span className="text-gold">📋</span>
            <span>Historial de Pedidos</span>
          </div>
          <span className="text-gray-400">{showOrders ? "↑" : "→"}</span>
        </Button>

        <Button 
          variant="destructive"
          onClick={handleLogout}
          className="w-full bg-red-600 hover:bg-red-700 p-4 h-auto flex items-center justify-center space-x-3"
        >
          <span>🚪</span>
          <span>Cerrar Sesión</span>
        </Button>
      </div>

      {/* Order History */}
      {showOrders && (
        <div className="space-y-4">
          <h3 className="text-lg font-bold">Historial de Pedidos</h3>
          
          {orders?.length === 0 ? (
            <Card className="bg-card-bg border-none">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gray-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-xl">📦</span>
                </div>
                <p className="text-gray-400">No tienes pedidos aún</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {orders?.map((order) => (
                <Card key={order.id} className="bg-card-bg border-none">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">Pedido #{order.id}</h4>
                      {getStatusBadge(order.status)}
                    </div>
                    
                    <div className="space-y-2 text-sm text-gray-400">
                      <p>Fecha: {new Date(order.createdAt).toLocaleDateString()}</p>
                      <p>Total: S/ {order.total}</p>
                      <p>Productos: {order.orderItems?.length || 0}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
