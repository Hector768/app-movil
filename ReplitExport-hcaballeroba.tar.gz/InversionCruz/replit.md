# Replit.md

## Overview

This is a mobile-first e-commerce web application for "Inversiones Cruz Angeles," a Peruvian melamine distributor. The application is built as a Progressive Web App (PWA) with a modern full-stack architecture featuring React frontend, Express.js backend, and PostgreSQL database with Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **Styling**: Tailwind CSS with shadcn/ui components
- **UI Library**: Radix UI primitives with custom styling
- **Build Tool**: Vite with hot module replacement in development

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful endpoints with JSON responses
- **Middleware**: Custom logging, error handling, and authentication middleware

### Mobile-First Design
- **Responsive**: Optimized for mobile devices with max-width container
- **PWA Features**: Service worker, manifest.json, offline capabilities
- **Touch Interface**: Bottom navigation, mobile-optimized forms
- **Performance**: Image optimization, lazy loading, minimal bundle size

## Key Components

### Authentication System
- **Provider**: Replit Auth integration for secure user management
- **Flow**: OAuth-based authentication with persistent sessions
- **User Storage**: PostgreSQL with user profile management
- **Session Management**: PostgreSQL-backed session store with TTL

### Product Management
- **Catalog**: Product listing with search and filtering capabilities
- **Categories**: Filter by type, color, thickness, and brand
- **Images**: Unsplash integration for product imagery
- **Search**: Full-text search across product names and descriptions

### Shopping Cart System
- **Persistence**: Server-side cart storage per authenticated user
- **Operations**: Add, remove, update quantities, clear cart
- **Real-time Updates**: Optimistic updates with TanStack Query
- **Integration**: Cart badge in navigation with live count

### Order Management
- **Checkout Process**: Address collection and order creation
- **WhatsApp Integration**: Automatic message generation for customer service
- **Order History**: User can view past orders and order details
- **Status Tracking**: Order status management system

### Contact System
- **Form Handling**: Contact form with validation
- **WhatsApp Integration**: Direct message forwarding to business WhatsApp
- **Lead Management**: Contact information storage for follow-up

## Data Flow

### Authentication Flow
1. User visits landing page
2. Clicks login/register button
3. Redirected to Replit Auth provider
4. OAuth flow completes and user is redirected back
5. Session established and user profile created/updated
6. Access granted to protected features

### Shopping Flow
1. User browses product catalog
2. Searches/filters products as needed
3. Adds products to cart
4. Reviews cart and proceeds to checkout
5. Provides delivery address and notes
6. Order created and WhatsApp message generated
7. User redirected to order confirmation

### Data Synchronization
- **Client-Server**: TanStack Query handles caching and synchronization
- **Real-time Updates**: Optimistic updates with server reconciliation
- **Error Handling**: Automatic retries with user feedback

## External Dependencies

### Core Dependencies
- **Database**: PostgreSQL via Neon serverless
- **Authentication**: Replit Auth with OpenID Connect
- **Styling**: Tailwind CSS + shadcn/ui components
- **State Management**: TanStack Query for server state
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns for date manipulation

### Development Tools
- **Build System**: Vite with TypeScript support
- **Database Migrations**: Drizzle Kit for schema management
- **Development Server**: Hot reload with Vite dev server
- **Code Quality**: TypeScript strict mode, ESLint configuration

### External Services
- **Image Hosting**: Unsplash for product and promotional images
- **WhatsApp Integration**: wa.me links for customer communication
- **Maps Integration**: Google Maps links for location sharing

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot reload
- **Database**: Neon PostgreSQL with connection pooling
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, REPL_ID
- **Asset Serving**: Vite handles static assets and HMR

### Production Build
- **Frontend**: Vite build to dist/public directory
- **Backend**: esbuild bundle to dist/index.js
- **Static Assets**: Served by Express.js in production
- **Database**: Same Neon PostgreSQL instance with migrations

### Deployment Configuration
- **Platform**: Designed for Replit deployment
- **Process**: Single node process serving both API and static files
- **Database**: Automatic schema synchronization with Drizzle
- **Session Storage**: PostgreSQL-backed sessions for persistence

### Performance Optimizations
- **Code Splitting**: Automatic with Vite
- **Image Optimization**: WebP support, lazy loading
- **Caching**: Service worker caches for offline functionality
- **Bundle Size**: Tree shaking and minimal dependencies

## Changelog

- June 30, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.