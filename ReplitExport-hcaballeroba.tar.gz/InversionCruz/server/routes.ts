import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProductSchema, insertCartItemSchema, insertOrderSchema, insertContactSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Product routes
  app.get('/api/products', async (req, res) => {
    try {
      const { search, category, brand, color, thickness } = req.query;
      
      let products;
      if (search) {
        products = await storage.searchProducts(search as string);
      } else if (category || brand || color || thickness) {
        products = await storage.filterProducts({
          category: category as string,
          brand: brand as string,
          color: color as string,
          thickness: thickness as string,
        });
      } else {
        products = await storage.getAllProducts();
      }
      
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get('/api/products/:id', async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Cart routes
  app.get('/api/cart', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error) {
      console.error("Error fetching cart:", error);
      res.status(500).json({ message: "Failed to fetch cart" });
    }
  });

  app.post('/api/cart', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cartItemData = insertCartItemSchema.parse({
        ...req.body,
        userId,
      });
      
      const cartItem = await storage.addToCart(cartItemData);
      res.json(cartItem);
    } catch (error) {
      console.error("Error adding to cart:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid cart item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add to cart" });
    }
  });

  app.patch('/api/cart/:id', isAuthenticated, async (req: any, res) => {
    try {
      const cartItemId = parseInt(req.params.id);
      const { quantity } = req.body;
      
      if (!quantity || quantity < 1) {
        return res.status(400).json({ message: "Invalid quantity" });
      }
      
      const cartItem = await storage.updateCartItem(cartItemId, quantity);
      res.json(cartItem);
    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  app.delete('/api/cart/:id', isAuthenticated, async (req: any, res) => {
    try {
      const cartItemId = parseInt(req.params.id);
      await storage.removeFromCart(cartItemId);
      res.json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Error removing from cart:", error);
      res.status(500).json({ message: "Failed to remove from cart" });
    }
  });

  app.delete('/api/cart', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.clearCart(userId);
      res.json({ message: "Cart cleared" });
    } catch (error) {
      console.error("Error clearing cart:", error);
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });

  // Order routes
  app.post('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { deliveryAddress, additionalNotes, orderItems } = req.body;
      
      // Calculate total from cart items
      const cartItems = await storage.getCartItems(userId);
      
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }
      
      const total = cartItems.reduce((sum, item) => 
        sum + (parseFloat(item.product.price) * item.quantity), 0
      );
      
      const orderData = insertOrderSchema.parse({
        userId,
        deliveryAddress,
        additionalNotes: additionalNotes || null,
        total: total.toString(),
        status: "pending",
      });
      
      const orderItemsData = cartItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.product.price,
      }));
      
      const order = await storage.createOrder(orderData, orderItemsData);
      
      // Clear the cart after order creation
      await storage.clearCart(userId);
      
      // In a real implementation, integrate with WhatsApp Business API
      const whatsappMessage = `Nuevo pedido #${order.id}\n` +
        `Cliente: ${req.user.claims.first_name || ''} ${req.user.claims.last_name || ''}\n` +
        `Teléfono: ${req.user.claims.phone || 'No proporcionado'}\n` +
        `Dirección: ${deliveryAddress}\n` +
        `Total: S/ ${total.toFixed(2)}\n` +
        `Productos:\n${cartItems.map(item => 
          `- ${item.product.name} x${item.quantity} - S/ ${(parseFloat(item.product.price) * item.quantity).toFixed(2)}`
        ).join('\n')}` +
        (additionalNotes ? `\n\nNotas: ${additionalNotes}` : '');
      
      console.log("WhatsApp message to send:", whatsappMessage);
      
      res.json({ order, whatsappMessage });
    } catch (error) {
      console.error("Error creating order:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.get('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get('/api/orders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  // Contact routes
  app.post('/api/contacts', async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      
      // In a real implementation, send WhatsApp message or email
      const whatsappMessage = `Nuevo mensaje de contacto\n` +
        `Nombre: ${contact.name}\n` +
        `Teléfono: ${contact.phone}\n` +
        `Mensaje: ${contact.message}`;
      
      console.log("WhatsApp contact message:", whatsappMessage);
      
      res.json({ contact, whatsappMessage });
    } catch (error) {
      console.error("Error creating contact:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send contact message" });
    }
  });

  // User profile routes
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { firstName, lastName, phone, address } = req.body;
      
      const updatedUser = await storage.upsertUser({
        id: userId,
        firstName,
        lastName,
        phone,
        address,
        email: req.user.claims.email,
        profileImageUrl: req.user.claims.profile_image_url,
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Initialize products if none exist
  app.post('/api/admin/init-products', async (req, res) => {
    try {
      const existingProducts = await storage.getAllProducts();
      
      if (existingProducts.length === 0) {
        const initialProducts = [
          // Melaminas Básicas
          {
            name: "Melamina Blanco Premium",
            description: "Panel de melamina blanco premium con acabado suave y resistente",
            price: "75.90",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Básica",
            brand: "Masisa",
            color: "Blanco",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Blanco Nieve 18mm",
            description: "Panel melamina blanco nieve extra grueso para mayor resistencia",
            price: "89.50",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Básica",
            brand: "Masisa",
            color: "Blanco",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Negro Intenso",
            description: "Panel de melamina negro intenso con acabado brillante sofisticado",
            price: "92.00",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Básica",
            brand: "Masisa",
            color: "Negro",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          
          // Melaminas Madera
          {
            name: "Melamina Roble Natural Veteado",
            description: "Panel con acabado madera roble natural con vetas pronunciadas",
            price: "89.90",
            imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Madera",
            brand: "Trupan",
            color: "Roble",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Nogal Americano",
            description: "Panel nogal americano oscuro con textura de madera auténtica",
            price: "95.90",
            imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Madera",
            brand: "Trupan",
            color: "Nogal",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Cerezo Brasileño",
            description: "Panel cerezo brasileño con tonos cálidos y acabado natural",
            price: "87.50",
            imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Madera",
            brand: "Arauco",
            color: "Cerezo",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Cedro Rústico",
            description: "Panel cedro rústico con textura pronunciada ideal para muebles clásicos",
            price: "82.90",
            imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Madera",
            brand: "Arauco",
            color: "Cedro",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Caoba Premium",
            description: "Panel caoba premium con acabado elegante y duradero",
            price: "98.90",
            imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Madera",
            brand: "Masisa",
            color: "Caoba",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          
          // Melaminas Contemporáneas
          {
            name: "Melamina Gris Cemento",
            description: "Panel gris cemento contemporáneo con acabado mate moderno",
            price: "78.50",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Contemporánea",
            brand: "Trupan",
            color: "Gris",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Gris Grafito",
            description: "Panel gris grafito oscuro ideal para diseños minimalistas",
            price: "85.00",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Contemporánea",
            brand: "Masisa",
            color: "Gris",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Beige Arena",
            description: "Panel beige arena con tonos neutros perfectos para espacios cálidos",
            price: "79.90",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Contemporánea",
            brand: "Arauco",
            color: "Beige",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          
          // Melaminas Especiales
          {
            name: "Melamina Mármol Carrara",
            description: "Panel con diseño mármol carrara blanco veteado elegante",
            price: "125.90",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Especial",
            brand: "Masisa",
            color: "Mármol",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Concreto Industrial",
            description: "Panel con textura concreto para diseños industriales modernos",
            price: "115.50",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Especial",
            brand: "Trupan",
            color: "Concreto",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Melamina Oxide Metálico",
            description: "Panel con acabado metálico oxidado para diseños únicos",
            price: "135.00",
            imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Melamina Especial",
            brand: "Masisa",
            color: "Metálico",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          
          // Tableros Especializados
          {
            name: "Tablero MDF 15mm",
            description: "Tablero MDF crudo listo para recubrir o pintar",
            price: "45.90",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Tableros",
            brand: "Arauco",
            color: "Natural",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Tablero MDF 18mm",
            description: "Tablero MDF crudo extra grueso para mayor resistencia",
            price: "52.90",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Tableros",
            brand: "Arauco",
            color: "Natural",
            thickness: "18mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          {
            name: "Tablero Aglomerado 15mm",
            description: "Tablero aglomerado económico para estructuras internas",
            price: "35.50",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Tableros",
            brand: "Trupan",
            color: "Natural",
            thickness: "15mm",
            dimensions: "2.44m x 1.22m",
            inStock: true,
          },
          
          // Accesorios
          {
            name: "Canto PVC Blanco 22mm",
            description: "Canto de PVC blanco para acabados de melamina blanca",
            price: "3.50",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Accesorios",
            brand: "Rehau",
            color: "Blanco",
            thickness: "0.5mm",
            dimensions: "50m x 22mm",
            inStock: true,
          },
          {
            name: "Canto ABS Roble 22mm",
            description: "Canto ABS texturizado que combina con melamina roble",
            price: "4.20",
            imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Accesorios",
            brand: "Rehau",
            color: "Roble",
            thickness: "1mm",
            dimensions: "50m x 22mm",
            inStock: true,
          },
          {
            name: "Pegamento para Canto",
            description: "Adhesivo especial para aplicación de cantos termofusibles",
            price: "25.90",
            imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
            category: "Accesorios",
            brand: "Henkel",
            color: "Transparente",
            thickness: "N/A",
            dimensions: "1kg",
            inStock: true,
          }
        ];
        
        for (const productData of initialProducts) {
          await storage.createProduct(productData);
        }
        
        res.json({ message: "Products initialized successfully" });
      } else {
        res.json({ message: "Products already exist" });
      }
    } catch (error) {
      console.error("Error initializing products:", error);
      res.status(500).json({ message: "Failed to initialize products" });
    }
  });

  // Reset and load complete product catalog
  app.post('/api/admin/reset-catalog', async (req, res) => {
    try {
      // Clear existing products
      const existingProducts = await storage.getAllProducts();
      for (const product of existingProducts) {
        await storage.deleteProduct(product.id);
      }

      // Load complete melamine catalog
      const products = [
        // Melaminas Básicas
        { name: "Melamina Blanco Premium", description: "Panel de melamina blanco premium con acabado suave y resistente", price: "75.90", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Básica", brand: "Masisa", color: "Blanco", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Blanco Nieve 18mm", description: "Panel melamina blanco nieve extra grueso para mayor resistencia", price: "89.50", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Básica", brand: "Masisa", color: "Blanco", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Negro Intenso", description: "Panel de melamina negro intenso con acabado brillante sofisticado", price: "92.00", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Básica", brand: "Masisa", color: "Negro", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        
        // Melaminas Madera
        { name: "Melamina Roble Natural Veteado", description: "Panel con acabado madera roble natural con vetas pronunciadas", price: "89.90", imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Madera", brand: "Trupan", color: "Roble", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Nogal Americano", description: "Panel nogal americano oscuro con textura de madera auténtica", price: "95.90", imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Madera", brand: "Trupan", color: "Nogal", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Cerezo Brasileño", description: "Panel cerezo brasileño con tonos cálidos y acabado natural", price: "87.50", imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Madera", brand: "Arauco", color: "Cerezo", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Cedro Rústico", description: "Panel cedro rústico con textura pronunciada ideal para muebles clásicos", price: "82.90", imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Madera", brand: "Arauco", color: "Cedro", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Caoba Premium", description: "Panel caoba premium con acabado elegante y duradero", price: "98.90", imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Madera", brand: "Masisa", color: "Caoba", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        
        // Melaminas Contemporáneas
        { name: "Melamina Gris Cemento", description: "Panel gris cemento contemporáneo con acabado mate moderno", price: "78.50", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Contemporánea", brand: "Trupan", color: "Gris", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Gris Grafito", description: "Panel gris grafito oscuro ideal para diseños minimalistas", price: "85.00", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Contemporánea", brand: "Masisa", color: "Gris", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Beige Arena", description: "Panel beige arena con tonos neutros perfectos para espacios cálidos", price: "79.90", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Contemporánea", brand: "Arauco", color: "Beige", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        
        // Melaminas Especiales
        { name: "Melamina Mármol Carrara", description: "Panel con diseño mármol carrara blanco veteado elegante", price: "125.90", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Especial", brand: "Masisa", color: "Mármol", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Concreto Industrial", description: "Panel con textura concreto para diseños industriales modernos", price: "115.50", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Especial", brand: "Trupan", color: "Concreto", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Melamina Oxide Metálico", description: "Panel con acabado metálico oxidado para diseños únicos", price: "135.00", imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Melamina Especial", brand: "Masisa", color: "Metálico", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        
        // Tableros Especializados
        { name: "Tablero MDF 15mm", description: "Tablero MDF crudo listo para recubrir o pintar", price: "45.90", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Tableros", brand: "Arauco", color: "Natural", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Tablero MDF 18mm", description: "Tablero MDF crudo extra grueso para mayor resistencia", price: "52.90", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Tableros", brand: "Arauco", color: "Natural", thickness: "18mm", dimensions: "2.44m x 1.22m", inStock: true },
        { name: "Tablero Aglomerado 15mm", description: "Tablero aglomerado económico para estructuras internas", price: "35.50", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Tableros", brand: "Trupan", color: "Natural", thickness: "15mm", dimensions: "2.44m x 1.22m", inStock: true },
        
        // Accesorios
        { name: "Canto PVC Blanco 22mm", description: "Canto de PVC blanco para acabados de melamina blanca", price: "3.50", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Accesorios", brand: "Rehau", color: "Blanco", thickness: "0.5mm", dimensions: "50m x 22mm", inStock: true },
        { name: "Canto ABS Roble 22mm", description: "Canto ABS texturizado que combina con melamina roble", price: "4.20", imageUrl: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Accesorios", brand: "Rehau", color: "Roble", thickness: "1mm", dimensions: "50m x 22mm", inStock: true },
        { name: "Pegamento para Canto", description: "Adhesivo especial para aplicación de cantos termofusibles", price: "25.90", imageUrl: "https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200", category: "Accesorios", brand: "Henkel", color: "Transparente", thickness: "N/A", dimensions: "1kg", inStock: true }
      ];

      for (const productData of products) {
        await storage.createProduct(productData);
      }

      res.json({ message: `Catálogo actualizado exitosamente con ${products.length} productos` });
    } catch (error) {
      console.error("Error resetting catalog:", error);
      res.status(500).json({ message: "Failed to reset catalog" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
