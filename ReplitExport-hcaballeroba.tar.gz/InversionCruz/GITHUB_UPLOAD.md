# 📦 Cómo subir a GitHub - Paso a paso

## Método 1: Descarga directa desde Replit (MÁS FÁCIL)

1. **En tu Repl actual**:
   - Haz clic en los **3 puntos (⋮)** arriba a la derecha
   - Selecciona **"Download as zip"**
   - Se descarga automáticamente `workspace.zip`

2. **En tu computadora**:
   - Extrae el archivo ZIP
   - Renombra la carpeta a `inversiones-cruz-angeles`

3. **En GitHub**:
   - Crea nuevo repositorio: `inversiones-cruz-angeles`
   - Arrastra toda la carpeta extraída
   - Escribe: "Aplicación móvil Inversiones Cruz Angeles"
   - Haz clic en **"Commit changes"**

## Método 2: Git commands (si sabes Git)

```bash
# En tu computadora después de extraer el ZIP
cd inversiones-cruz-angeles
git init
git add .
git commit -m "Aplicación móvil Inversiones Cruz Angeles"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/inversiones-cruz-angeles.git
git push -u origin main
```

## 🔧 Después de subir a GitHub

1. **Despliega en Vercel** (gratis):
   - Ve a vercel.com
   - Conecta tu GitHub
   - Selecciona el repositorio
   - Agrega variables de entorno:
     ```
     DATABASE_URL=tu_postgresql_url
     SESSION_SECRET=clave-secreta-larga
     REPL_ID=tu-repl-id
     ```

2. **Carga los productos**:
   ```bash
   curl -X POST https://tu-app.vercel.app/api/admin/reset-catalog
   ```

## ✅ Tu app estará lista

- URL: `https://inversiones-cruz-angeles.vercel.app`
- Catálogo completo de 21 productos
- Carrito y pedidos WhatsApp
- PWA instalable en móviles

¡Listo para recibir clientes reales!