# Guía de Despliegue - Inversiones Cruz Angeles

## 📦 Archivos del Proyecto

### Archivos principales necesarios:
```
inversiones-cruz-angeles/
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   ├── pages/
│   │   ├── App.tsx
│   │   ├── index.css
│   │   └── main.tsx
│   ├── public/
│   │   └── manifest.json
│   └── index.html
├── server/
│   ├── index.ts
│   ├── routes.ts
│   ├── storage.ts
│   ├── db.ts
│   ├── replitAuth.ts
│   └── vite.ts
├── shared/
│   └── schema.ts
├── package.json
├── package-lock.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.ts
├── postcss.config.js
├── drizzle.config.ts
├── components.json
├── README.md
├── .env.example
└── .gitignore
```

## 🚀 Pasos para subir a GitHub:

1. **Descarga el ZIP** desde Replit usando el botón "Download as zip"

2. **Extrae el archivo** en tu computadora

3. **Crea un nuevo repositorio** en GitHub:
   - Nombre: `inversiones-cruz-angeles`
   - Público o privado según prefieras

4. **Sube los archivos** a GitHub:
   - Arrastra y suelta toda la carpeta
   - O usa Git commands si conoces

5. **Configura el despliegue** en plataformas como:
   - Vercel (recomendado)
   - Netlify
   - Railway
   - Render

## ⚙️ Variables de entorno necesarias:

```bash
DATABASE_URL=postgresql://...
SESSION_SECRET=tu-clave-secreta-muy-larga
REPL_ID=tu-repl-id
REPLIT_DOMAINS=tu-dominio.vercel.app
```

## 📱 Después del despliegue:

1. Cargar productos iniciales:
```bash
curl -X POST https://tu-dominio.com/api/admin/reset-catalog
```

2. Tu aplicación estará disponible para el público

## 🔗 URL de ejemplo:
`https://inversiones-cruz-angeles.vercel.app`

## 📞 Soporte:
Si necesitas ayuda con el despliegue, puedes contactar al desarrollador.