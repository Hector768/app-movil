# Inversiones Cruz Angeles - Aplicación Móvil de Melamina

Una aplicación web progresiva (PWA) para Inversiones Cruz Angeles, distribuidor líder de melamina de alta calidad en Perú.

## 🚀 Características

- **Catálogo Completo**: 21 productos de melamina organizados en 6 categorías
- **Diseño Mobile-First**: Optimizado para dispositivos móviles
- **Carrito de Compras**: Funcionalidad completa de e-commerce
- **Integración WhatsApp**: Pedidos directos via WhatsApp
- **PWA**: Instalable como aplicación nativa
- **Autenticación**: Sistema seguro con Replit Auth

## 📱 Categorías de Productos

- **Melaminas Básicas**: Blanco, Negro (3 productos)
- **Melaminas Madera**: Roble, Nogal, Cerezo, Cedro, Caoba (5 productos)
- **Melaminas Contemporáneas**: Gris, Beige (3 productos)
- **Melaminas Especiales**: Mármol, Concreto, Metálico (3 productos)
- **Tableros**: MDF, Aglomerado (3 productos)
- **Accesorios**: Cantos, Pegamentos (3 productos)

## 🛠 Tecnologías

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express + PostgreSQL
- **Base de Datos**: Neon PostgreSQL con Drizzle ORM
- **Autenticación**: Replit Auth (OpenID Connect)
- **Build**: Vite + ESBuild

## 🌐 Demo en Vivo

Visita la aplicación: [https://tu-repl-name.replit.app](https://tu-repl-name.replit.app)

## 📦 Instalación Local

1. Clona el repositorio:
```bash
git clone https://github.com/tu-usuario/inversiones-cruz-angeles.git
cd inversiones-cruz-angeles
```

2. Instala las dependencias:
```bash
npm install
```

3. Configura las variables de entorno:
```bash
# Crea un archivo .env con:
DATABASE_URL=tu_url_postgresql
SESSION_SECRET=tu_secreto_session
REPL_ID=tu_repl_id
```

4. Inicializa la base de datos:
```bash
npm run db:push
```

5. Carga los productos iniciales:
```bash
curl -X POST http://localhost:5000/api/admin/reset-catalog
```

6. Inicia el servidor de desarrollo:
```bash
npm run dev
```

## 🏢 Sobre Inversiones Cruz Angeles

Distribuidores especializados en melamina de alta calidad con más de 15 años de experiencia en el mercado peruano. Trabajamos con las mejores marcas: Masisa, Trupan, Arauco y Rehau.

### Contacto
- **WhatsApp**: +51 XXX XXX XXX
- **Email**: contacto@cruzangeles.pe
- **Dirección**: Lima, Perú

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor, abre un issue primero para discutir los cambios que te gustaría hacer.

---

Desarrollado con ❤️ para transformar espacios con elegancia y durabilidad.