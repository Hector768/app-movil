import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'tabs/inicio',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then(m => m.LoginPage),
  },
  {
    path: 'tabs',
    loadComponent: () => import('./tabs/tabs.page').then(m => m.TabsPage),
    children: [
      {
        path: 'inicio',
        loadComponent: () => import('./inicio/inicio.page').then(m => m.InicioPage),
      },
      {
        path: 'productos',
        loadComponent: () => import('./productos/productos.page').then(m => m.ProductosPage),
      },
      {
        path: 'carrito',
        loadComponent: () => import('./carrito/carrito.page').then(m => m.CarritoPage),
      },
      {
        path: 'contacto',
        loadComponent: () => import('./contacto/contacto.page').then(m => m.ContactoPage),
      },
      {
        path: 'nosotros',
        loadComponent: () => import('./nosotros/nosotros.page').then(m => m.NosotrosPage),
      },
      {
        path: '',
        redirectTo: 'inicio',
        pathMatch: 'full',
      }
    ]
  }
];
